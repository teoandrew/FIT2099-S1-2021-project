package game;

/**
 * EcoPoints for the user to buy things from a vending machine.
 * Static methods for ecoPoints to be updated automatically accordingly.
 */
public class EcoPoints {
    public static int points;

    // static methods for ecoPoints to be updated automatically accordingly

    /**
     * Getter.
     * To get the current number of EcoPoints a player has.
     *
     * @return the number of EcoPoints a player has
     */
    public static int getEcoPoints(){
        return points;
    }

    /**
     * Adds EcoPoints to the player
     *
     * @param addPoints amount of points to be added to the player's total
     */
    public static void addEcoPoints(int addPoints){
        points = points + addPoints;
    }

    /**
     * Removes EcoPoints accordingly.
     * Used when a player buys something from the vending machine.
     *
     * @param addPoint amount of EcoPoints to be subtracted from the player's total
     */
    public static void removeEcoPoints(int addPoint){
        points = points - addPoint;
    }
}
