package game.dinoActions;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Ground;
import game.Behaviour;
import game.lake.Fish;
import game.lake.Lakes;
import game.dinosaurs.Pterodactyl;

import java.util.ArrayList;
import java.util.Random;

/**
 * The dinosaur (pterodactyl specifically) swoops down to eat fish from a lake below it.
 */
public class SwoopDownEatFish extends Action implements Behaviour {

    private Ground targetLake;

    /**
     * Constructor. Initialises lake to swoop down to.
     *
     * @param target lake to swoop down to
     */
    public SwoopDownEatFish(Ground target) {
        this.targetLake = target;
    }


    /**
     * Perform the Action.
     *
     * @see edu.monash.fit2099.engine.Action#execute(Actor, GameMap)
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of what happened that can be displayed to the user.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        String retString = "";

        Random random = new Random();
        int randomInt = random.nextInt(4);

        ArrayList<Fish> lakeFishes = ((Lakes) targetLake).getFish();

        for (int i = 0; i <= randomInt; i++)
        {
            lakeFishes.remove(i);
        }

        ((Lakes) targetLake).setFish(lakeFishes);

        ((Pterodactyl) actor).setWaterPoints(((Pterodactyl) actor).getWaterPoints() + 30);

        retString = "Pterodactly ate " + String.valueOf(randomInt) + " fishes.";

        System.out.println(retString);
        return retString;
    }


    /**
     * @param actor the Actor acting
     * @param map the GameMap containing the Actor
     * @return the action to carry out
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        return this;
    }


    /**
     * Returns a descriptive string
     *
     * @see edu.monash.fit2099.engine.Action#menuDescription(Actor)
     *
     * @param actor The actor performing the action.
     * @return the text we put on the menu
     */
    @Override
    public String menuDescription(Actor actor) {
        return null;
    }
}
