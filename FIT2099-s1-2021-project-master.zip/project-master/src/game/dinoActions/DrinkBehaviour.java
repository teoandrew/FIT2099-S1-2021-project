package game.dinoActions;

import edu.monash.fit2099.engine.*;
import game.Behaviour;
import game.lake.Lakes;
import game.dinoCapabilities.DinosaurSpecies;
import game.dinosaurs.Allosaur;
import game.dinosaurs.Brachiosaur;
import game.dinosaurs.Stegosaur;

/**
 * Drink water from lake behaviour of dinosaurs.
 */
public class DrinkBehaviour extends Action implements Behaviour {

    private Ground targetLake;
    private Location lakeLocation;


    /**
     * Constructor. Initialises lake to drink from and location of the lake.
     *
     * @param targetLake lake to drink from
     * @param lakeLocation location of lake
     */
    public DrinkBehaviour(Ground targetLake, Location lakeLocation) {
        this.targetLake = targetLake;
        this.lakeLocation = lakeLocation;
    }


    /**
     * Perform the Action.
     *
     * @see edu.monash.fit2099.engine.Action#execute(Actor, GameMap)
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of what happened that can be displayed to the user.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        String retString = "";

        if (actor.hasCapability(DinosaurSpecies.STEGOSAUR) || actor.hasCapability(DinosaurSpecies.ALLOSAUR))
        {
            ((Stegosaur) actor).setWaterLevel(((Stegosaur) actor).getWaterLevel() + 30);
            ((Lakes) targetLake).setWater(((Lakes) targetLake).getWater() - 1);
            retString = "Stegosaur drank from lake";
        }
        else if (actor.hasCapability(DinosaurSpecies.BRACHIOSAUR))
        {
            ((Brachiosaur) actor).setWaterLevel(((Brachiosaur) actor).getWaterLevel() + 80);
            ((Lakes) targetLake).setWater(((Lakes) targetLake).getWater() - 1);
            retString = "Brachiosaur drank from lake";
        }
        else if (actor.hasCapability(DinosaurSpecies.ALLOSAUR))
        {
            ((Allosaur) actor).setWaterLevel(((Allosaur) actor).getWaterLevel() + 30);
            ((Lakes) targetLake).setWater(((Lakes) targetLake).getWater() - 1);
            retString = "Allosaur drank from lake";
        }

        return retString;
    }


    /**
     * @param actor the Actor acting
     * @param map the GameMap containing the Actor
     * @return the action to carry out
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        if (lakeLocation == null)
            return null;

        Location here = map.locationOf(actor);
        Location there = lakeLocation;

        NumberRange xs, ys;
        if (here.x() == there.x() || here.y() == there.y())
        {
            xs = new NumberRange(Math.min(here.x(), there.x()), Math.abs(here.x() - there.x()) + 1);
            ys = new NumberRange(Math.min(here.y(), there.y()), Math.abs(here.y() - there.y()) + 1);

            for (int xCoordinate : xs)
            {
                for (int yCoordinate : ys)
                {
                    if (map.at(xCoordinate, yCoordinate).getGround().blocksThrownObjects())
                    {
                        return null;
                    }
                }
            }
            return this;
        }
        return null;
    }


    /**
     * Returns a descriptive string
     *
     * @see edu.monash.fit2099.engine.Action#menuDescription(Actor)
     *
     * @param actor The actor performing the action.
     * @return the text we put on the menu
     */
    @Override
    public String menuDescription(Actor actor) {
        return null;
    }
}
