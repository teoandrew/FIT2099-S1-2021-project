package game.dinoActions;

import edu.monash.fit2099.engine.*;
import game.Behaviour;
import game.Bush;
import game.Tree;
import game.dinoCapabilities.DinosaurSpecies;
import game.dinoCapabilities.EdibleForDinosaur;
import game.dinosaurs.Brachiosaur;
import game.dinosaurs.Stegosaur;

/**
 * Eating behaviour of herbivores.
 */
public class HerbivoreEatBehaviour extends Action implements Behaviour {

    private Ground target;
    private Location targetLocation;


    /**
     * Constructor. Initialises target to eat and the location of it.
     *
     * @param target target to eat
     * @param targetLocation location of target to eat
     */
    public HerbivoreEatBehaviour(Ground target, Location targetLocation) {
        this.target = target;
        this.targetLocation = targetLocation;
    }


    /**
     * Perform the Action.
     *
     * @see edu.monash.fit2099.engine.Action#execute(Actor, GameMap)
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of what happened that can be displayed to the user.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        String retString = "";

        if (actor.hasCapability(DinosaurSpecies.STEGOSAUR))
        {
            if (target.hasCapability(EdibleForDinosaur.STEGOSAUR_CAN_EAT))
            {
                ((Bush) target).removeFruit();
                ((Stegosaur) actor).setFoodLevel(((Stegosaur) actor).getFoodLevel() + 10);

                retString = "Stegosaur ate";
            }
        }
        else if (actor.hasCapability(DinosaurSpecies.BRACHIOSAUR))
        {
            if (target.hasCapability(EdibleForDinosaur.BRACHIOSAUR_CAN_EAT))
            {
                // eat all the fruits on the tree or until its food level is sufficient
                int brachFoodLevel = ((Brachiosaur) actor).getFoodLevel();
                int numOfFruitsOnTree = ((Tree) target).getFruits().size();

                while ((numOfFruitsOnTree > 0) && (brachFoodLevel <= 70))
                {
                    ((Tree) target).removeFruit();
                    ((Brachiosaur) actor).setFoodLevel(((Brachiosaur) actor).getFoodLevel() + 5);

                    brachFoodLevel = ((Brachiosaur) actor).getFoodLevel();
                    numOfFruitsOnTree = ((Tree) target).getFruits().size();
                }

                retString = "Brachiosaur ate";
            }
        }

        return retString;
    }


    /**
     * @param actor the Actor acting
     * @param map the GameMap containing the Actor
     * @return the action to carry out
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        Location here = map.locationOf(actor);
        Location there = targetLocation;

        if (targetLocation == null)
            return null;

        NumberRange xs, ys;
        if (here.x() == there.x() || here.y() == there.y())
        {
            xs = new NumberRange(Math.min(here.x(), there.x()), Math.abs(here.x() - there.x()) + 1);
            ys = new NumberRange(Math.min(here.y(), there.y()), Math.abs(here.y() - there.y()) + 1);

            for (int xCoordinate : xs)
            {
                for (int yCoordinate : ys)
                {
                    if (map.at(xCoordinate, yCoordinate).getGround().blocksThrownObjects())
                    {
                        return null;
                    }
                }
            }
            return this;
        }
        return null;
    }

    /**
     * Returns a descriptive string
     *
     * @see edu.monash.fit2099.engine.Action#menuDescription(Actor)
     *
     * @param actor The actor performing the action.
     * @return the text we put on the menu
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " eats";
    }
}
