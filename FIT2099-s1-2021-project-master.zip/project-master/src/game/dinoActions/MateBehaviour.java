package game.dinoActions;

import edu.monash.fit2099.engine.*;
import game.Behaviour;
import game.dinoCapabilities.DinoPregnantStatus;
import game.dinoCapabilities.DinosaurBreedingStatus;
import game.dinoCapabilities.DinosaurGender;

/**
 * For the dinosaurs to have a bit of fun. And also for reproductive purposes.
 */
public class MateBehaviour extends Action implements Behaviour {

    private Actor target;

    /**
     * Constructor. Initialises dinosaur to mate with.
     *
     * @param target dinosaur to mate with
     */
    public MateBehaviour(Actor target) {
        this.target = target;
    }


    /**
     * Perform the Action.
     *
     * @see edu.monash.fit2099.engine.Action#execute(Actor, GameMap)
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of what happened that can be displayed to the user.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        String retString = "";

        // make the female pregnant
        if(actor.hasCapability(DinosaurGender.FEMALE))
        {
            actor.addCapability(DinoPregnantStatus.PREGNANT);
            actor.removeCapability(DinosaurBreedingStatus.READY_TO_BREED);

            retString = actor + " is now pregnant";
        } else if (target.hasCapability(DinosaurGender.FEMALE))
        {
            target.addCapability(DinoPregnantStatus.PREGNANT);
            target.removeCapability(DinosaurBreedingStatus.READY_TO_BREED);

            retString = target + " is now pregnant";
        }

        return retString;
    }


    /**
     * @param actor the Actor acting
     * @param map the GameMap containing the Actor
     * @return the action to carry out
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        Location here = map.locationOf(actor);
        Location there = map.locationOf(target);

        if (there == null)
        {
            return null;
        }

        NumberRange xs, ys;
        if (here.x() == there.x() || here.y() == there.y())
        {
            xs = new NumberRange(Math.min(here.x(), there.x()), Math.abs(here.x() - there.x()) + 1);
            ys = new NumberRange(Math.min(here.y(), there.y()), Math.abs(here.y() - there.y()) + 1);

            for (int x : xs)
            {
                for (int y : ys)
                {
                    if (map.at(x, y).getGround().blocksThrownObjects())
                    {
                        return null;
                    }
                }
            }
            return this;
        }
        return null;
    }


    /**
     * Returns a descriptive string
     *
     * @see edu.monash.fit2099.engine.Action#menuDescription(Actor)
     *
     * @param actor The actor performing the action.
     * @return the text we put on the menu
     */
    @Override
    public String menuDescription(Actor actor) {
        return null;
    }
}
