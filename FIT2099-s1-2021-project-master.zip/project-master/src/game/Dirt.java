package game;

import edu.monash.fit2099.engine.Exit;
import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Location;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * A class that represents bare dirt.
 */
public class Dirt extends Ground {
	// added association with Bush
	private ArrayList<Bush> bushList = new ArrayList<>();

	/**
	 * Constructor.
	 * Dirt is displayed as '.' on the GameMap.
	 */
	public Dirt() {
		super('.');
	}

	/**
	 * A method to grow a bush.
	 * The bush is added to bushList for the sake of
	 * keeping track of the number of bushes we have.
	 *
	 * @param bush a bush
	 */
	private void growBush(Bush bush){
		bushList.add(bush);
	}

	/**
	 * For dirt to experience the passage of time.
	 * At every turn, some new bushes are created.
	 *
	 * @param location The location of the Ground
	 */
	@Override
	public void tick(Location location) {
		super.tick(location);

		Random random = new Random();
		int randomInt = random.nextInt(10);
		Bush bush = new Bush();
		int noOfBush =0;
		int noOfTree = 0;
		List<Exit> nearby = location.getExits();
		for(int i =0; i < nearby.size(); i++){
			if(nearby.get(i).getDestination().getGround() instanceof Bush){
				noOfBush++;
			}
			else if(nearby.get(i).getDestination().getGround() instanceof Tree){
				noOfTree ++;
			}
		}
		if(bushList.size()<10) {
			// to check if there is 2 or more bushes nearby and has no tree nearby. Also have a 10 percent chance of growth
			if (noOfBush > 1 && randomInt == 0 && noOfTree == 0) {
				bushList.add(bush);
				location.setGround(bushList.get(0));
			} else if (noOfTree == 0 && randomInt == 0) {
				bushList.add(bush);
				location.setGround(bush);
			}
		}
	}
}
