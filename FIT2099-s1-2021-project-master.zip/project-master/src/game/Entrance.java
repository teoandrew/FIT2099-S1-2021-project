package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Item;

public class Entrance extends Item {
    /***
     * Constructor.
     *  @param name the name of this Item
     * @param displayChar the character to use to represent this item if it is on the ground
     * @param portable true if and only if the Item can be picked up
     */

    /**
     * Constructor.
     */
    public Entrance(){
        super("Gateway To Paradise", '|', false);
    }


    /**
     * To let the player enter.
     *
     * @param action action to add
     */
    public void addAction(Action action){
        this.allowableActions.add(action);
    }
}
