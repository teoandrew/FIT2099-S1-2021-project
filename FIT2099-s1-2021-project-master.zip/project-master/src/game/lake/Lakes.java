package game.lake;

import edu.monash.fit2099.engine.*;
import game.Rain;
import game.dinoCapabilities.Fly;

import java.util.ArrayList;
import java.util.Random;

/**
 * Lakes for the park. Lakes are good. They are a water
 * source for the dinosaurs and water is important.
 */
public class Lakes extends Ground implements Rain {
    private ArrayList<Rain> raining = new ArrayList<>();
    private ArrayList<Fish> fish = new ArrayList<>();
    private boolean rain;
    private int water = 25;

    /**
     * Constructor.
     */
    //Display character of lakes
    public Lakes() {
        super('~');
        Fish salmon = new Fish();
        fish.add(salmon);
        fish.add(salmon);
        fish.add(salmon);
        fish.add(salmon);
        fish.add(salmon);
    }

    /**
     * Getter to retrieve water
     *
     * @return water value
     */
    public int getWater() {
        return water;
    }

    /**
     * Setter to set water
     *
     * @param water water value to set
     */
    public void setWater(int water) {
        this.water = water;
    }

    /**
     * Getter to retrieve fish
     *
     * @return fish value
     */
    public ArrayList<Fish> getFish() {
        return fish;
    }

    /**
     * Setter to set fish
     *
     * @param fish fish ArrayList to set
     */
    public void setFish(ArrayList<Fish> fish) {
        this.fish = fish;
    }

    /**
     * For lakes to experience the passage of time.
     *
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location){
        super.tick(location);
        Random random = new Random();
        int randomInt = random.nextInt(10);
        int randomRain = random.nextInt(6);
        double rainfall = 1;
        if(fish.size() == 0 ){

        }
        if(randomInt >=4){
            Fish fish = new Fish();
            createFish(fish);
        }
        if(water==0){
            addCapability(LakeDrink.CANNOT_DRINK_WATER);
        }
        if(water!=0){
            addCapability(LakeDrink.DRINK_WATER);
        }
        if(getRainfall()){
            water += 20*(randomRain/10);
//            System.out.println("HEAVY RAIN");
        }
        if(fish.size() < 3) {
            if (hasCapability(LakeHasFishStatus.LAKE_HAS_FISH))
            {
                removeCapability(LakeHasFishStatus.LAKE_HAS_FISH);
            }
        } else if (fish.size() >= 3)
        {
            if (!hasCapability(LakeHasFishStatus.LAKE_HAS_FISH))
            {
                addCapability(LakeHasFishStatus.LAKE_HAS_FISH);
            }
        }

    }

    /**
     * To create fishes. Created fishes will be added
     * to the fish ArrayList
     * @param fish
     */
    public void createFish(Fish fish){
        this.fish.add(fish);
    }

    /**
     * Only an Actor that has flying capabilities can enter.
     *
     * @param actor the Actor to check
     * @return true or false. If true, can enter.
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        return actor.hasCapability(Fly.FLYING);
    }

    /**
     * To check if there is rainfall or not.
     *
     * @return true if there's rain or false if there is no rain
     */
    @Override
    public boolean getRainfall() {
        return rain ;
    }

    /**
     * To set the rainfall to true or false.
     *
     * @param rainfall boolean value
     */
    @Override
    public void setRainfall(boolean rainfall) {
        rain = rainfall;
    }
}
