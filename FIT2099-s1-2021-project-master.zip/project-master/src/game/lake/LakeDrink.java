package game.lake;

/**
 * An enum class for the lake to have a can drink water
 * or cannot drink water status.
 */
public enum LakeDrink {
    DRINK_WATER,
    CANNOT_DRINK_WATER
}
