package game.lake;

import edu.monash.fit2099.engine.Item;

/**
 * Fish in the lake. Tasty for Pterodactyls.
 */
public class Fish extends Item {

    /***
     * Constructor.
     *  @param name the name of this Item
     * @param displayChar the character to use to represent this item if it is on the ground
     * @param portable true if and only if the Item can be picked up
     */
    public Fish() {
        super("Ikan Balis", 'F', true);
    }

}
