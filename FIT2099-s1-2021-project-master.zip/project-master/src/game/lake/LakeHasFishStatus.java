package game.lake;

/**
 * An enum class for a lake to have a "have fish" status.
 */
public enum LakeHasFishStatus {
    LAKE_HAS_FISH
}
