package game.dinosaurs;

import edu.monash.fit2099.engine.*;
import game.*;
import game.dinoActions.*;
import game.dinoCapabilities.*;
import game.lake.LakeHasFishStatus;
import game.movingBehaviours.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * A flying dinosaur.
 */
public class Pterodactyl extends Actor {
    private Random rand = new Random();
    private List<Behaviour> behaviours = new ArrayList<>();
    private int foodLevel;
    private int foodLevelThreshold;
    private int waterLevel;
    private int waterLevelThreshold;

    private int flightDuration;
    private int flightDurationThreshold;

    private int waterPoints;

    /**
     * Constructor.
     * All Brachiosaurs are represented by a 'P'.
     *
     * @param name the name of this Pterodactyl
     */
    public Pterodactyl(String name) {
        super(name, 'P', 50);

        foodLevel = hitPoints;
        maxHitPoints = 100;
        foodLevelThreshold = maxHitPoints;

        waterLevel = 60;
        waterLevelThreshold = 100;

        flightDuration = flightDurationThreshold = 30;

        this.addCapability(DinosaurSpecies.PTERODACTYL);
        this.addCapability(Fly.FLYING);
        this.addCapability(DinosaurDiet.CARNIVORE);

        behaviours.add(new WanderBehaviour());
    }

    /**
     * Getter to retrieve waterPoints
     *
     * @return waterPoints value
     */
    public int getWaterPoints() {
        return waterPoints;
    }


    /**
     * Setter to set waterPoints
     *
     * @param waterPoints waterPoints value to set
     */
    public void setWaterPoints(int waterPoints) {
        this.waterPoints = waterPoints;
    }


    /**
     * Returns a collection of the Actions that the otherActor can do to the current Actor.
     *
     * @param otherActor the Actor that might be performing attack
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return A collection of Actions.
     */
    @Override
    public Actions getAllowableActions(Actor otherActor, String direction, GameMap map) {
        return new Actions(new AttackAction(this));
    }


    /**
     * Figure out what to do next.
     *
     * @see edu.monash.fit2099.engine.Actor#playTurn(Actions, Action, GameMap, Display)
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return the action to perform
     */
    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        Location locationOfActor = map.locationOf(this);

        hitPoints--;
        foodLevel--;
        waterLevel--;
        flightDuration--;

        if (foodLevel > 50 && foodLevel <= foodLevelThreshold)
        {
            // change the breeding status
            if ((!hasCapability(DinosaurBreedingStatus.READY_TO_BREED) && (!hasCapability(DinoPregnantStatus.PREGNANT))))
            {
                addCapability(DinosaurBreedingStatus.READY_TO_BREED);
            }

            // moving from hungry to not hungry
            if (foodLevel > 90 && foodLevel <= foodLevelThreshold && hasCapability(DinosaurHungerStatus.HUNGRY))
            {
                removeCapability(DinosaurHungerStatus.HUNGRY);
                addCapability(DinosaurHungerStatus.NOT_HUNGRY);
            }

            // moving from not hungry to hungry
            if(foodLevel > 0 && foodLevel <= 90 && hasCapability(DinosaurHungerStatus.NOT_HUNGRY))
            {
                removeCapability(DinosaurHungerStatus.NOT_HUNGRY);
                addCapability(DinosaurHungerStatus.HUNGRY);
            }

            behaviours.clear();

            FindMate findMate = new FindMate();
            Actor target = findMate.findFeasibleMate(this, map);

            behaviours.add(new FollowBehaviour(target));
            behaviours.add(new MateBehaviour(target));
        }
        else if (foodLevel > 0 && foodLevel <= 50)
        {
            // change the breeding status
            if (hasCapability(DinosaurBreedingStatus.READY_TO_BREED))
            {
                removeCapability(DinosaurBreedingStatus.READY_TO_BREED);
            }

            // moving from unconscious to hungry
            if (hasCapability(DinosaurConciousStatus.UNCONCSCIOUS))
            {
                removeCapability(DinosaurConciousStatus.UNCONCSCIOUS);
                addCapability(DinosaurHungerStatus.HUNGRY);
            }

            behaviours.clear();

            FindFood findFood = new FindFood();
            Actor target = findFood.findFeasibleCarnivorousFoodSource(this, map);

            behaviours.add(new FollowBehaviour(target));
        }
        else if (foodLevel == 0 || waterLevel == 0)
        {
            // moving from hungry to unconscious
            if (hasCapability(DinosaurHungerStatus.HUNGRY))
            {
                removeCapability(DinosaurHungerStatus.HUNGRY);
                addCapability(DinosaurConciousStatus.UNCONCSCIOUS);

                behaviours.clear();
            }
        }
        else if (foodLevel == -20 || waterLevel == -15)
        {
            // moving from unconscious to death
            if (hasCapability(DinosaurConciousStatus.UNCONCSCIOUS))
            {
                removeCapability(DinosaurConciousStatus.UNCONCSCIOUS);
                addCapability(DinosaurConciousStatus.DEAD);

                addCapability(EdibleForDinosaur.ALLOSAUR_CAN_EAT);
            }
        }
        else if (foodLevel == -40)
        {
            map.removeActor(this);
        }

        // prioritise waterLevel
        if (waterLevel >= 40)
        {
            // thirsty to not thirsty
            if (hasCapability(DinosaurThirstStatus.THIRSTY))
            {
                removeCapability(DinosaurThirstStatus.THIRSTY);
            }
        }
        else if (waterLevel < 40)
        {
            // not thirsty to thirsty
            if (!hasCapability(DinosaurThirstStatus.THIRSTY))
            {
                addCapability(DinosaurThirstStatus.THIRSTY);

                behaviours.clear();

                FindLake findLake = new FindLake();
                Ground target = findLake.findFeasibleLakeSource(this, map);
                Location lakeLocation = findLake.getLakeLocation();

                behaviours.add(new GoToBehaviour(target, lakeLocation));
                behaviours.add(new DrinkBehaviour(target, lakeLocation));
            }
        }

        // flying and walking behaviours
        if (flightDuration == 0)
        {
            removeCapability(Fly.FLYING);
            addCapability(EdibleForDinosaur.ALLOSAUR_CAN_EAT);

            FindTree findTree = new FindTree();
            Tree target = findTree.findTreeToWalkTo(this, map);
            Location treeLocation = findTree.getTreeLocation();

            behaviours.add(new GoToBehaviour(target, treeLocation));
        }

        if(locationOfActor.getGround().hasCapability(LakeHasFishStatus.LAKE_HAS_FISH)){
            actions.add(new SwoopDownEatFish(locationOfActor.getGround()));
        }

        if((locationOfActor.getGround() instanceof Tree) && (!this.hasCapability(Fly.FLYING)))
        {
            flightDuration = 30;
            addCapability(Fly.FLYING);
        }

        for (Behaviour factory : behaviours){
            Action action = factory.getAction(this, map);
            if(action != null)
                return action;
        }

        return actions.get(rand.nextInt(actions.size()));
    }
}