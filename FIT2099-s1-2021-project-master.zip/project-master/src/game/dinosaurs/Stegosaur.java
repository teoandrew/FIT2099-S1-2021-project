package game.dinosaurs;


import edu.monash.fit2099.engine.*;
import game.AttackAction;
import game.Behaviour;
import game.dinoActions.DrinkBehaviour;
import game.dinoActions.HerbivoreEatBehaviour;
import game.dinoActions.MateBehaviour;
import game.dinoCapabilities.*;
import game.movingBehaviours.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * A herbivorous dinosaur.
 *
 */
public class Stegosaur extends Actor {
	private Random rand = new Random();
	private List<Behaviour> behaviours = new ArrayList<>();
	private int foodLevel;
	private final int foodLevelThreshold;
	private int waterLevel;
	private int waterLevelThreshold;

	/** 
	 * Constructor.
	 * All Stegosaurs are represented by a 'd'.
	 *
	 * @see WanderBehaviour
	 * 
	 * @param name the name of this Stegosaur
	 */
	public Stegosaur(String name) {
		super(name, 'd', 50);

		foodLevel = hitPoints;
		maxHitPoints = 100;
		foodLevelThreshold = maxHitPoints;

		waterLevel = 60;
		waterLevelThreshold = 100;

		this.addCapability(DinosaurSpecies.STEGOSAUR);
		this.addCapability(DinosaurDiet.HERBIVORE);

		behaviours.add(new WanderBehaviour());
	}

	/**
	 * Getter to retrieve foodLevel
	 *
	 * @return foodLevel value
	 */
	public int getFoodLevel() {
		return foodLevel;
	}


	/**
	 * Setter to set foodLevel
	 *
	 * @param foodLevel foodLevel value to set
	 */
	public void setFoodLevel(int foodLevel) {
		if (foodLevel <= foodLevelThreshold)
		{
			this.foodLevel = foodLevel;
		} else
		{
			this.foodLevel = foodLevelThreshold;
		}
	}

	/**
	 * Getter to retrieve waterLevel
	 *
	 * @return waterLevel value
	 */
	public int getWaterLevel() {
		return waterLevel;
	}


	/**
	 * Setter to set waterLevel
	 *
	 * @param waterLevel waterLevel value to set
	 */
	public void setWaterLevel(int waterLevel) {
		if (waterLevel <= foodLevelThreshold)
		{
			this.waterLevel = waterLevel;
		} else
		{
			this.waterLevel = waterLevelThreshold;
		}
	}


	/**
	 * Returns a collection of the Actions that the otherActor can do to the current Actor.
	 *
	 * @param otherActor the Actor that might be performing attack
	 * @param direction  String representing the direction of the other Actor
	 * @param map        current GameMap
	 * @return A collection of Actions.
	 */
	@Override
	public Actions getAllowableActions(Actor otherActor, String direction, GameMap map) {
		return new Actions(new AttackAction(this));
	}


	/**
	 * Figure out what to do next.
	 *
	 * @see edu.monash.fit2099.engine.Actor#playTurn(Actions, Action, GameMap, Display)
	 *
	 * @param actions    collection of possible Actions for this Actor
	 * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
	 * @param map        the map containing the Actor
	 * @param display    the I/O object to which messages may be written
	 * @return the action to perform
	 */
	@Override
	public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
		hitPoints--;
		foodLevel--;
		waterLevel--;

		if (foodLevel > 50 && foodLevel <= foodLevelThreshold)
		{
			// change the breeding status
			if ((!this.hasCapability(DinosaurBreedingStatus.READY_TO_BREED) && (!this.hasCapability(DinoPregnantStatus.PREGNANT))))
			{
				this.addCapability(DinosaurBreedingStatus.READY_TO_BREED);
			}

			// moving from hungry to not hungry
			if (foodLevel > 90 && foodLevel <= foodLevelThreshold && this.hasCapability(DinosaurHungerStatus.HUNGRY))
			{
				this.removeCapability(DinosaurHungerStatus.HUNGRY);
				this.addCapability(DinosaurHungerStatus.NOT_HUNGRY);
			}

			// moving from not hungry to hungry
			if(foodLevel > 0 && foodLevel <= 90 && this.hasCapability(DinosaurHungerStatus.NOT_HUNGRY))
			{
				this.removeCapability(DinosaurHungerStatus.NOT_HUNGRY);
				this.addCapability(DinosaurHungerStatus.HUNGRY);
			}

			behaviours.clear();

			FindMate findMate = new FindMate();
			Actor target = findMate.findFeasibleMate(this, map);

			behaviours.add(new FollowBehaviour(target));
			behaviours.add(new MateBehaviour(target));
		}
		else if (foodLevel > 0 && foodLevel <= 50)
		{
			// change the breeding status
			if (this.hasCapability(DinosaurBreedingStatus.READY_TO_BREED))
			{
				this.removeCapability(DinosaurBreedingStatus.READY_TO_BREED);
			}

			// moving from unconscious to hungry
			if (this.hasCapability(DinosaurConciousStatus.UNCONCSCIOUS))
			{
				this.removeCapability(DinosaurConciousStatus.UNCONCSCIOUS);
				this.addCapability(DinosaurHungerStatus.HUNGRY);
			}

			behaviours.clear();

			FindFood findFood = new FindFood();
			Ground target = findFood.findFeasibleFoodHerbivorousSource(this, map);
			Location subjectLocation = findFood.getLocationOfTarget();

			behaviours.add(new GoToBehaviour(target, subjectLocation));
			behaviours.add(new HerbivoreEatBehaviour(target, subjectLocation));
		}
		else if (foodLevel == 0 || waterLevel == 0)
		{
			// moving from hungry to unconscious
			if (this.hasCapability(DinosaurHungerStatus.HUNGRY))
			{
				this.removeCapability(DinosaurHungerStatus.HUNGRY);
				this.addCapability(DinosaurConciousStatus.UNCONCSCIOUS);

				behaviours.clear();
			}
		}
		else if (foodLevel == -20 || waterLevel == -15)
		{
			// moving from unconscious to death
			if (this.hasCapability(DinosaurConciousStatus.UNCONCSCIOUS))
			{
				this.removeCapability(DinosaurConciousStatus.UNCONCSCIOUS);
				this.addCapability(DinosaurConciousStatus.DEAD);

				this.addCapability(EdibleForDinosaur.ALLOSAUR_CAN_EAT);
			}
		}
		else if (foodLevel == -40)
		{
			map.removeActor(this);
		}

		// prioritise waterLevel
		if (waterLevel < 40)
		{
			// not thirsty to thirsty
			if (!this.hasCapability(DinosaurThirstStatus.THIRSTY))
			{
				this.addCapability(DinosaurThirstStatus.THIRSTY);

				behaviours.clear();

				FindLake findLake = new FindLake();
				Ground target = findLake.findFeasibleLakeSource(this, map);
				Location lakeLocation = findLake.getLakeLocation();

				behaviours.add(new GoToBehaviour(target, lakeLocation));
				behaviours.add(new DrinkBehaviour(target, lakeLocation));
		}
		else if (waterLevel >= 40)
		{
			// thirsty to not thirsty
			if (this.hasCapability(DinosaurThirstStatus.THIRSTY))
			{
				this.removeCapability(DinosaurThirstStatus.THIRSTY);
			}
			}
		}

		for (Behaviour factory : behaviours){
			Action action = factory.getAction(this, map);
			if(action != null)
				return action;
		}

		return actions.get(rand.nextInt(actions.size()));
	}
}
