package game.dinosaurs;

import edu.monash.fit2099.engine.*;
import game.*;
import game.dinoCapabilities.DinosaurConciousStatus;
import game.dinoCapabilities.DinosaurSpecies;
import game.dinoCapabilities.DinosaurHungerStatus;
import game.dinoCapabilities.EdibleForDinosaur;
import game.movingBehaviours.WanderBehaviour;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Small cute baby dinosaurs.
 */
public class BabyDinosaur extends Actor {
    private Random rand = new Random();
    private List<Behaviour> behaviours = new ArrayList<>();
    private int foodLevel;
    private int foodLevelThreshold;
    private int age = 0;
    private int waterLevel;
    private int waterLevelThreshold;


    /**
     * Constructor.
     * All BabyDinosaurs are represented by a '4'.
     *
     * @see WanderBehaviour
     *
     * @param name the name of this Brachiosaur
     */
    public BabyDinosaur(String name, DinosaurSpecies dinosaurSpecies) {
        super(name, '8', 10);

        foodLevel = hitPoints;
        maxHitPoints = 100;
        foodLevelThreshold = maxHitPoints;

        waterLevel = 60;
        waterLevelThreshold = 100;

        addCapability(dinosaurSpecies);

        behaviours.add(new WanderBehaviour());
    }


    /**
     * Returns a collection of the Actions that the otherActor can do to the current Actor.
     *
     * @param otherActor the Actor that might be performing attack
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return A collection of Actions.
     */
    @Override
    public Actions getAllowableActions(Actor otherActor, String direction, GameMap map) {
        return new Actions(new AttackAction(this));
    }

    /**
     * Figure out what to do next.
     *
     * @see edu.monash.fit2099.engine.Actor#playTurn(Actions, Action, GameMap, Display)
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return the action to perform
     */
    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        hitPoints--;
        foodLevel--;
        age++;

        // food level check
        if (foodLevel > 90 && foodLevel <= foodLevelThreshold) {
            // from hungry to not hungry
            if (hasCapability(DinosaurHungerStatus.HUNGRY)) {
                removeCapability(DinosaurHungerStatus.HUNGRY);
                addCapability(DinosaurHungerStatus.NOT_HUNGRY);
            }
        } else if (foodLevel > 0 && foodLevel <= 90) {
            // from not hungry to hungry
            if (hasCapability(DinosaurHungerStatus.NOT_HUNGRY)) {
                removeCapability(DinosaurHungerStatus.NOT_HUNGRY);
                addCapability(DinosaurHungerStatus.HUNGRY);
            }
        } else if (foodLevel == 0) {
            // moving from hungry to unconscious
            if (hasCapability(DinosaurHungerStatus.HUNGRY)) {
                removeCapability(DinosaurHungerStatus.HUNGRY);
                addCapability(DinosaurConciousStatus.UNCONCSCIOUS);

                behaviours.clear();
            }
        } else if (foodLevel == -15)
        {
            // moving from unconscious to death
            if (hasCapability(DinosaurConciousStatus.UNCONCSCIOUS))
            {
                removeCapability(DinosaurConciousStatus.UNCONCSCIOUS);
                addCapability(DinosaurConciousStatus.DEAD);

                addCapability(EdibleForDinosaur.ALLOSAUR_CAN_EAT);
            }
        } else if (foodLevel == -25)
        {
            map.removeActor(this);
        }

        // age check
        if(age == 30)
        {
            if (this.hasCapability(DinosaurSpecies.STEGOSAUR))
            {
                Stegosaur fullGrownStegosaur = new Stegosaur("Grownup Stegosaur");
                Location locationOfBaby = map.locationOf(this);
                map.removeActor(this);
                map.addActor(fullGrownStegosaur, locationOfBaby);
            }
        }
        if (age == 50)
        {
            if (this.hasCapability(DinosaurSpecies.BRACHIOSAUR))
            {
                Brachiosaur fullGrownBrachiosaur = new Brachiosaur("Grownup Brachiosaur");
                Location locationOfBaby = map.locationOf(this);
                map.removeActor(this);
                map.addActor(fullGrownBrachiosaur, locationOfBaby);
            }
            else if (this.hasCapability(DinosaurSpecies.ALLOSAUR))
            {
                Allosaur fullGrownAllosaur = new Allosaur("Grownup Allosaur");
                Location locationOfBaby = map.locationOf(this);
                map.removeActor(this);
                map.addActor(fullGrownAllosaur, locationOfBaby);
            }
        }

        for (Behaviour factory : behaviours){
            Action action = factory.getAction(this, map);
            if(action != null)
                return action;
        }

        return actions.get(rand.nextInt(actions.size()));
    }
}
