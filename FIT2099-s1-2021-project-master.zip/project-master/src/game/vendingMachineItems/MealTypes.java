package game.vendingMachineItems;

/**
 * An enum class to give a meal kit either vegetarian or carnivore capabilities.
 * Herbivourous dinosaurs can only eat vegetarian meal kits and carnivorous dinosaurs
 * can only eat carnivorous meal kits.
 */
public enum MealTypes {
    VEGETARIAN_MEAL_KIT,
    CARNIVORE_MEAL_KIT
}
