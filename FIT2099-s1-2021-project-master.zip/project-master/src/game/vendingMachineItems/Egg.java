package game.vendingMachineItems;

import game.PortableItem;

/**
 * Represents a dinosaur egg. It's portable, that's cool.
 */
public class Egg extends PortableItem {

    /**
     * Constructor.
     * All dinosaur eggs are displayed as '0' on the GameMap.
     *
     * @param name name of the Egg
     * @param displayChar the display character of the egg to be shown on the GameMap
     */
    public Egg(String name, char displayChar) {
        super(name, displayChar);
        displayChar = '0';
    }
}
