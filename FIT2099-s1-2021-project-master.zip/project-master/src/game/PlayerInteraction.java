package game;

/**
 * Capabilities of a player to pick a fruit from a bush or tree.
 */
public enum PlayerInteraction {
    PICK_UP_FRUIT_BUSH,
    PICK_UP_FRUIT_TREE
}
