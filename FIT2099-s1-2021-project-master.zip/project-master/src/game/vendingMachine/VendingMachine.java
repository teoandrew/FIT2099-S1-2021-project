package game.vendingMachine;

import edu.monash.fit2099.engine.*;
import game.dinoCapabilities.Fly;

/**
 * A vending machine. Used by the player to buy cool things. You can even buy a gun.
 */
public class VendingMachine extends Ground {

    /**
     * Constructor.
     * Vending machines are displayed as 'V' on the GameMap.
     */
    public VendingMachine() {
        super('V');
    }

    /**
     * Executes the VendingMachine Action.
     *
     * @param actor the Actor acting
     * @param location the current Location
     * @param direction the direction of the Ground from the Actor
     * @return the Action made by the VendingMachine after a player does something to it.
     */
    @Override
    public Actions allowableActions(Actor actor, Location location, String direction){
        return new Actions(new VendingMachineAction());
    }

    /**
     * So that the Player cannot step over the VendingMachine.
     *
     * @param actor the Actor to check
     * @return permission to whether or not the Player can step into the VendingMachine's location.
     * Only an Actor that has flying capabilities can enter.
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        return actor.hasCapability(Fly.FLYING);
    }
}