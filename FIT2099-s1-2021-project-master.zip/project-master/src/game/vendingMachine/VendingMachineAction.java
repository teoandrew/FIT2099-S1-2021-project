package game.vendingMachine;

import edu.monash.fit2099.engine.*;
import game.dinoCapabilities.DinosaurSpecies;
import game.fruit.Fruit;
import game.vendingMachineItems.Egg;
import game.vendingMachineItems.LaserGun;
import game.vendingMachineItems.MealKit;
import game.vendingMachineItems.MealTypes;

import java.util.Scanner;

import static game.EcoPoints.getEcoPoints;
import static game.EcoPoints.removeEcoPoints;

/**
 * The Action made by the VendingMachine after the Player selects
 * something from it.
 */
public class VendingMachineAction extends Action {

    int points = getEcoPoints();


    /**
     * Executes the VendingMachine Action.
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return the description of the result of the interaction between the VendingMachine and the Player.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        int selection;
        do{
            selection = selectMenuItem();
            switch(selection){
                case 1:
                    Fruit fruit= new Fruit();
                    if(validPurchase(30,fruit)){
                        actor.addItemToInventory(fruit);
                        removeEcoPoints(30);
                        System.out.println(actor.getInventory());
                    }
                    System.out.println("You currently have " + getEcoPoints() + " Eco Points");
                    break;

                case 2:
                    Item mealKit1 = new MealKit("VegetarianMeal", 'v');
                    mealKit1.addCapability(MealTypes.VEGETARIAN_MEAL_KIT);
                    if(validPurchase(100,mealKit1)){
                        actor.addItemToInventory(mealKit1);
                        removeEcoPoints(100);
                        System.out.println(actor.getInventory());
                    }
                    System.out.println("You currently have " + getEcoPoints() + " Eco Points");
                    break;
                case 3:
                    Item mealKit2 = new MealKit("CarnivoreMeal", 'c');
                    mealKit2.addCapability(MealTypes.CARNIVORE_MEAL_KIT);
                    if(validPurchase(500,mealKit2)){
                        actor.addItemToInventory(mealKit2);
                        removeEcoPoints(500);
                        System.out.println(actor.getInventory());
                    }
                    System.out.println("You currently have " + getEcoPoints() + " Eco Points");
                    break;
                case 4:
                    Item stegosaurusEgg = new Egg("StegosaurEgg", 's');
                    stegosaurusEgg.addCapability(DinosaurSpecies.STEGOSAUR);
                    if(validPurchase(200,stegosaurusEgg)){
                        actor.addItemToInventory(stegosaurusEgg);
                        removeEcoPoints(200);
                        System.out.println(actor.getInventory());
                    }
                    System.out.println("You currently have " + getEcoPoints() + " Eco Points");
                    break;
                case 5:
                    Item brachiosaurEgg = new Egg("BrachiosaurEgg", 'b');
                    brachiosaurEgg.addCapability(DinosaurSpecies.BRACHIOSAUR);
                    if(validPurchase(500,brachiosaurEgg)){
                        actor.addItemToInventory(brachiosaurEgg);
                        removeEcoPoints(500);
                        System.out.println(actor.getInventory());
                    }
                    System.out.println("You currently have " + getEcoPoints() + " Eco Points");
                    break;
                case 6:
                    Item allosaurEgg = new Egg("AllosaurEgg", 'a');
                    allosaurEgg.addCapability(DinosaurSpecies.ALLOSAUR);
                    if(validPurchase(1000,allosaurEgg)){
                        actor.addItemToInventory(allosaurEgg);
                        removeEcoPoints(1000);
                        System.out.println(actor.getInventory());
                    }
                    System.out.println("You currently have " + getEcoPoints() + " Eco Points");
                    break;
                case 7:
                    Item laserGun =  new LaserGun("Blaster",'g',50,"BOOM");
                    if(validPurchase(500,laserGun)){
                        actor.addItemToInventory(laserGun);
                        removeEcoPoints(500);
                        System.out.println(actor.getInventory());
                    }
                    System.out.println("You currently have " + getEcoPoints() + " Eco Points");
                    break;
                case 8:
            }
        }
        while(selection!=8);
        return "Thank you";
    }


    /**
     * Returns a descriptive string.
     *
     * @param actor the actor in question
     * @return a description
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Vending Machine";
    }


    /**
     * To check if the purchase request made by the Player is valid or not.
     *
     * @param points the number of EcoPoints for the Item
     * @param item the Item selected by the Player that they want to buy
     * @return whether or not the Player can buy the item
     */
    public boolean validPurchase(int points, Item item){
        boolean flag = false;
        if(item instanceof Fruit){
            if(getEcoPoints()>= points ){
                return true;
            }
        }else if(item instanceof MealKit) {
            if (item.hasCapability(MealTypes.VEGETARIAN_MEAL_KIT)) {
                if (getEcoPoints() >= points) {
                    return true;
                }
            } else if (item.hasCapability(MealTypes.CARNIVORE_MEAL_KIT)) {
                if (getEcoPoints() >= points) {
                    return true;
                }
            }
        }else if(item.hasCapability(DinosaurSpecies.STEGOSAUR)){
            if (getEcoPoints() >= points) {
                return true;
            }
        }else if(item.hasCapability(DinosaurSpecies.BRACHIOSAUR)) {
            if (getEcoPoints() >= points) {
                return true;
            }
        }else if(item.hasCapability(DinosaurSpecies.ALLOSAUR)) {
            if (getEcoPoints() >= points) {
                return true;
            }
        }else if(item.asWeapon() instanceof Weapon){
            if(getEcoPoints()>= points ){
                return true;
            }
        }
        return flag;
    }


    /**
     * Generates a menu so that the Player can make a selection.
     *
     * @return an Integer value selected by the Player
     */
    public static int selectMenuItem(){
        Scanner scanner = new Scanner(System.in);
        System.out.println();

        System.out.println("You currently have " + getEcoPoints() + " Eco Points");
        System.out.println("------------------------------------------");
        System.out.println("1) Fruit : cost = 30 point  ");
        System.out.println("2) Vegetarian Meal kit : cost = 100");
        System.out.println("3) Carnivore Meal kit: cost = 500");
        System.out.println("4) Stegosaurus eggs : cost = 200");
        System.out.println("5) Brachiosaur eggs : cost = 500");
        System.out.println("6) Allosaur eggs : cost = 1000");
        System.out.println("7) laser gun : cost 500");
        System.out.println("8) EXIT");
        System.out.println("------------------------------------------");
        System.out.println("Select your option: ");
        int optionChosen = scanner.nextInt();
        return optionChosen;
    }
}
