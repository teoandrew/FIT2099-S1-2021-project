package game;

import edu.monash.fit2099.engine.Item;

/**
 * Base class for any item that can be picked up and dropped.
 */
public class PortableItem extends Item {

	/**
	 * Constructor.
	 * Creates a PortableItem.
	 *
	 * @param name the name of the item
	 * @param displayChar the display character of the item to be shown on the GameMap
	 */
	public PortableItem(String name, char displayChar) {
		super(name, displayChar, true);
	}
}
