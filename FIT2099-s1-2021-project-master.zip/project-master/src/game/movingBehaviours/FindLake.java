package game.movingBehaviours;

import edu.monash.fit2099.engine.*;
import game.lake.LakeDrink;
import game.lake.Lakes;

/**
 * A class for the dinosaurs to be able to find the nearest available lake,
 * that is a water source.
 */
public class FindLake {

    private Location lakeLocation;

    /**
     * Getter to retrieve lakeLocation
     *
     * @return lakeLocation value
     */
    public Location getLakeLocation() {
        return lakeLocation;
    }


    /**
     * To find a feasible water source (a lake) for a dinosaur.
     *
     * @param actor the actor that's finding a food source
     * @param map the map the actor is in
     * @return a Ground object that is a feasible water source (a lake)
     */
    public Ground findFeasibleLakeSource(Actor actor, GameMap map) {
        NumberRange x = map.getXRange();
        NumberRange y = map.getYRange();

        Location locationAtIteration;
        Ground groundObjectAtIteration;

        Ground closestFeasibleLakeSource = null;
        Location feasibleLakeLocation = null;
        int closestDistance = Integer.MAX_VALUE;

        int distanceToActorAtIteration;

        for (int xCoordinate : x)
        {
            for (int yCoordinate : y)
            {
                locationAtIteration = map.at(xCoordinate, yCoordinate);
                groundObjectAtIteration = locationAtIteration.getGround();

                if (groundObjectAtIteration instanceof Lakes)
                {
                    if (groundObjectAtIteration.hasCapability(LakeDrink.DRINK_WATER))
                    {
                        distanceToActorAtIteration = distance(locationAtIteration, map.locationOf(actor));

                        if (distanceToActorAtIteration < closestDistance)
                        {
                            closestFeasibleLakeSource = groundObjectAtIteration;
                            closestDistance = distanceToActorAtIteration;
                            feasibleLakeLocation = locationAtIteration;
                        }
                    }
                }
            }
        }
        lakeLocation = feasibleLakeLocation;
        return closestFeasibleLakeSource;
    }


    /**
     * Compute the Manhattan distance between two locations.
     *
     * @param a the first location
     * @param b the first location
     * @return the number of steps between a and b if you only move in the four cardinal directions.
     */
    private int distance(Location a, Location b) {
        return Math.abs(a.x() - b.x()) + Math.abs(a.y() - b.y());
    }
}
