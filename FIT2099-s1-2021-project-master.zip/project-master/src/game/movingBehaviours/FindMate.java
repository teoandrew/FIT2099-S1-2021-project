package game.movingBehaviours;

import edu.monash.fit2099.engine.*;
import game.dinoCapabilities.DinosaurBreedingStatus;

/**
 * A class for the dinosaurs to be able to find the nearest possible/feasible mate.
 * This class is Tinder for dinosaurs.
 */
public class FindMate {

    /**
     * To find a feasible mate for a dinosaur.
     *
     * @param actor the actor that's looking for a mate
     * @param map the map the actor is in
     * @return the nearest possible mate
     */
    public Actor findFeasibleMate(Actor actor, GameMap map) {
        NumberRange x = map.getXRange();
        NumberRange y = map.getYRange();

        Location locationAtIteration;
        Actor actorAtIteration;

        Actor closestFeasibleActor = null;
        int closestDistance = Integer.MAX_VALUE;

        for (int xCoordinate : x)
        {
            for (int yCoordinate: y)
            {
                locationAtIteration = map.at(xCoordinate, yCoordinate);
                actorAtIteration = map.getActorAt(locationAtIteration);

                if (actorAtIteration != null)
                {
                    if (actorAtIteration.getClass().equals(actor.getClass()))
                    {
                        if (actorAtIteration.hasCapability(DinosaurBreedingStatus.READY_TO_BREED))
                        {
                            int distanceToActorAtIteration = distance(locationAtIteration, map.locationOf(actor));

                            if (distanceToActorAtIteration < closestDistance)
                            {
                                closestFeasibleActor = actorAtIteration;
                                closestDistance = distanceToActorAtIteration;
                            }
                        }
                    }
                }
            }
        }
        System.out.println(actor + " moving towards mate");

        return closestFeasibleActor;
    }


    /**
     * Compute the Manhattan distance between two locations.
     *
     * @param a the first location
     * @param b the first location
     * @return the number of steps between a and b if you only move in the four cardinal directions.
     */
    private int distance(Location a, Location b) {
        return Math.abs(a.x() - b.x()) + Math.abs(a.y() - b.y());
    }
}
