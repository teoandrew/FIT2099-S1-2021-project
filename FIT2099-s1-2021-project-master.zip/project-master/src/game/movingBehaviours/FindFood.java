package game.movingBehaviours;

import edu.monash.fit2099.engine.*;
import game.dinoCapabilities.DinosaurConciousStatus;
import game.dinoCapabilities.DinosaurSpecies;
import game.dinoCapabilities.EdibleForDinosaur;

/**
 * A class for the dinosaurs to be able to find the nearest available food source.
 */
public class FindFood {

    private Location locationOfTarget;


    /**
     * Getter to retrieve locationOfTarget
     *
     * @return locationOfTarget value
     */
    public Location getLocationOfTarget() {
        return locationOfTarget;
    }


    /**
     * To find a feasible food source for herbivorous dinosaurs.
     *
     * @param actor the actor that's finding a food source
     * @param map the map the actor is in
     * @return a Ground object that is a feasible herbivorous food source
     */
    public Ground findFeasibleFoodHerbivorousSource(Actor actor, GameMap map) {
        NumberRange x = map.getXRange();
        NumberRange y = map.getYRange();

        Location locationAtIteration;
        Ground groundObjectAtIteration;

        Ground closestFeasibleHerbivorousFoodSource = null;
        Location feasibleFoodSourceLocation = null;
        int closestDistance = Integer.MAX_VALUE;

        int distanceToActorAtIteration;

        for (int xCoordinate : x)
        {
            for (int yCoordinate : y)
            {
                locationAtIteration = map.at(xCoordinate, yCoordinate);
                groundObjectAtIteration = locationAtIteration.getGround();

                if (actor.hasCapability(DinosaurSpecies.STEGOSAUR))
                {
                    if (groundObjectAtIteration.hasCapability(EdibleForDinosaur.STEGOSAUR_CAN_EAT))
                    {
                        distanceToActorAtIteration = distance(locationAtIteration, map.locationOf(actor));

                        if (distanceToActorAtIteration < closestDistance)
                        {
                            closestFeasibleHerbivorousFoodSource = groundObjectAtIteration;
                            closestDistance = distanceToActorAtIteration;
                        }
                    }
                }
                else if (actor.hasCapability(DinosaurSpecies.BRACHIOSAUR))
                {
                    if (groundObjectAtIteration.hasCapability(EdibleForDinosaur.BRACHIOSAUR_CAN_EAT))
                    {
                        distanceToActorAtIteration = distance(locationAtIteration, map.locationOf(actor));

                        if (distanceToActorAtIteration < closestDistance)
                        {
                            closestFeasibleHerbivorousFoodSource = groundObjectAtIteration;
                            closestDistance = distanceToActorAtIteration;
                            feasibleFoodSourceLocation = locationAtIteration;
                        }
                    }
                }
            }
        }
        System.out.println(actor + " finding food");

        locationOfTarget = feasibleFoodSourceLocation;
        return closestFeasibleHerbivorousFoodSource;
    }


    /**
     * To find a feasible food source for carnivorous dinosaurs.
     *
     * @param actor the actor that's finding a food source
     * @param map the map the actor is in
     * @return a Ground object that is a feasible carnovorous food source
     */
    public Actor findFeasibleCarnivorousFoodSource(Actor actor, GameMap map) {
        NumberRange x = map.getXRange();
        NumberRange y = map.getYRange();

        Location locationAtIteration;
        Actor targetAtIteration = null;

        Actor closestFeasibleCarnivorousFoodSource = null;
        int closestDistance = Integer.MAX_VALUE;

        int distanceToActorAtIteration;

        for (int xCoordinate : x)
        {
            for (int yCoordinate : y)
            {
                locationAtIteration = map.at(xCoordinate, yCoordinate);

                if (locationAtIteration.getActor() != null)
                {
                    targetAtIteration = locationAtIteration.getActor();
                } else {
                    continue;
                }

                // for dead dinosaurs
                if (targetAtIteration.hasCapability(DinosaurConciousStatus.DEAD) &&
                        (targetAtIteration.hasCapability(EdibleForDinosaur.ALLOSAUR_CAN_EAT) ||
                                targetAtIteration.hasCapability(EdibleForDinosaur.PTERODACTYL_CAN_EAT)))
                {
                    distanceToActorAtIteration = distance(locationAtIteration, map.locationOf(actor));

                    if (distanceToActorAtIteration < closestDistance)
                    {
                        closestFeasibleCarnivorousFoodSource = targetAtIteration;
                        closestDistance = distanceToActorAtIteration;
                    }
                }
            }
        }
        return closestFeasibleCarnivorousFoodSource;
    }


    /**
     * Compute the Manhattan distance between two locations.
     *
     * @param a the first location
     * @param b the first location
     * @return the number of steps between a and b if you only move in the four cardinal directions.
     */
    private int distance(Location a, Location b) {
        return Math.abs(a.x() - b.x()) + Math.abs(a.y() - b.y());
    }
}
