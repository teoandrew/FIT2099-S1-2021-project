package game.movingBehaviours;

import edu.monash.fit2099.engine.*;
import game.Tree;

/**
 * A class for Pterodactyls to find the nearest tree when it can't fly anymore.
 */
public class FindTree {

    private Location treeLocation;


    /**
     * Getter to retrieve treeLocation
     *
     * @return treeLocation value
     */
    public Location getTreeLocation() {
        return treeLocation;
    }


    /**
     * To find the nearest tree that a Pterodactyl can walk to.
     *
     * @param actor the Pterodactyl that's walking and looking for the nearest tree
     * @param map the map the actor in is
     * @return the nearest possible tree
     */
    public Tree findTreeToWalkTo(Actor actor, GameMap map) {
        NumberRange x = map.getXRange();
        NumberRange y = map.getYRange();

        Location locationAtIteration;
        Ground groundObjectAtIteration;

        Tree closestTree = null;
        Location closestTreeLocation = null;
        int closestDistance = Integer.MAX_VALUE;

        int distanceToActorAtIteration;

        for (int xCoordinate : x)
        {
            for (int yCoordinate : y)
            {
                locationAtIteration = map.at(xCoordinate, yCoordinate);
                groundObjectAtIteration = locationAtIteration.getGround();

                if (groundObjectAtIteration instanceof Tree)
                {
                    distanceToActorAtIteration = distance(locationAtIteration, map.locationOf(actor));

                    if (distanceToActorAtIteration < closestDistance)
                    {
                        closestTree = (Tree) groundObjectAtIteration;
                        closestDistance = distanceToActorAtIteration;
                        closestTreeLocation = locationAtIteration;
                    }
                }
            }
        }
        treeLocation = closestTreeLocation;
        return closestTree;
    }


    /**
     * Compute the Manhattan distance between two locations.
     *
     * @param a the first location
     * @param b the first location
     * @return the number of steps between a and b if you only move in the four cardinal directions.
     */
    private int distance(Location a, Location b) {
        return Math.abs(a.x() - b.x()) + Math.abs(a.y() - b.y());
    }
}
