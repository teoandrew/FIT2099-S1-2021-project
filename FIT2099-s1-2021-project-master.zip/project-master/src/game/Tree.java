package game;

import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.Location;
import game.dinoCapabilities.EdibleForDinosaur;
import game.fruit.Fruit;

import java.util.ArrayList;
import java.util.Random;
import static game.EcoPoints.addEcoPoints;

/**
 * A tree. Trees are good. They provide oxygen. And fruits for the dinos.
 */
public class Tree extends Ground implements PlantTypes{
	private int age = 0;
	//added association for fruit
	private ArrayList<Item> fruits = new ArrayList<>();

	/**
	 * Constructor.
	 * Trees are displayed as '+' on the GameMap.
	 */
	public Tree() {
		super('+');

		addCapability(EdibleForDinosaur.BRACHIOSAUR_CAN_EAT);
	}

	/**
	 * Getter.
	 * Get the fruits available on a tree
	 *
	 * @return the fruits available on a tree
	 */
	public ArrayList<Item> getFruits() {
		return fruits;
	}

	/**
	 * For each time a fruit is created it is added to fruits
	 * The number of fruits in a bush can be calculated by using .size()
	 *
	 * @param fruit a fruit
	 */
	private void createFruit(Fruit fruit){
		fruits.add(fruit);

		// 1 point is updated to EcoPoints of the player
		addEcoPoints(1);
	}

	/**
	 * When a fruit is selected by the player or fall from the tree,
	 * or eaten by a brachiosaur, it is removed from the fruits ArrayList.
	 */
	@Override
	public void removeFruit(){
		if(fruits.size()>0){
			fruits.remove(0);
		}
	}

	/**
	 * For a tree to experience the passage of time.
	 * There is a possibility for (more) fruits to grow on the tree at every turn.
	 *
	 * @param location The location of the Ground
	 */
	@Override
	public void tick(Location location) {
		super.tick(location);
		Random random = new Random();
		int randomInt = random.nextInt(20);
		int generalRandom = random.nextInt(10);

		// 50 percent chance of getting selected
		if(generalRandom>=5){
			Fruit fruit = new Fruit();
			createFruit(fruit);
		}
		if(fruits.size()>0) {
			addCapability(PlayerInteraction.PICK_UP_FRUIT_TREE);
			if (randomInt == 0) {
				location.addItem(fruits.get(0));
				removeFruit();
			}
		}
	}
}
