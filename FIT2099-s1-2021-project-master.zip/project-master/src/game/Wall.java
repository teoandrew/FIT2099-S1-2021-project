package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Ground;
import game.dinoCapabilities.Fly;

/**
 * A wall in the GameMap.
 */
public class Wall extends Ground {

	/**
	 * Constructor.
	 * A Wall is displayed as '#' in the GameMap
	 */
	public Wall() {
		super('#');
	}

	/**
	 * An Actor cannot enter this location.
	 *
	 * @param actor the Actor to check
	 * @return whether or not an Actor can enter this location. They cannot.
	 */
	@Override
	public boolean canActorEnter(Actor actor) {
		return actor.hasCapability(Fly.FLYING);
	}

	/**
	 * Implement terrain that blocks thrown objects but not movement, or vice versa
	 *
	 * @return a boolean value
	 */
	@Override
	public boolean blocksThrownObjects() {
		return true;
	}
}
