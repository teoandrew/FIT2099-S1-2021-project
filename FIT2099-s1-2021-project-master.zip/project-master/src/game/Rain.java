package game;

import java.util.Random;

/**
 * A class for rain to fall upon the land (park). Rain is lovely.
 */
public interface Rain {

    /**
     * To check if there is rainfall or not.
     *
     * @return true if there's rain or false if there is no rain
     */
    boolean getRainfall();

    /**
     * To set the rainfall to true or false.
     *
     * @param rainfall boolean value
     */
    void setRainfall(boolean rainfall) ;

}
