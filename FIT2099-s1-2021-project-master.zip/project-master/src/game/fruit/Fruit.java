package game.fruit;

import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.Location;
import game.dinoCapabilities.EdibleForDinosaur;

/**
 * A fruit.
 */
public class Fruit extends Item{

    public int age;

    /**
     * Constructor.
     * Fruits are displayed as 'f' on the GameMap.
     */
    public Fruit() {
        super("Orange",'f',true);
        setAge(0);

        addCapability(EdibleForDinosaur.STEGOSAUR_CAN_EAT);
        addCapability(EdibleForDinosaur.BRACHIOSAUR_CAN_EAT);
    }

    /**
     * Getter.
     * To get the age of the fruit. For keeping track of the rotting and stuff.
     *
     * @return the valuye of the age of the fruit.
     */
    public int getAge() {
        return age;
    }

    /**
     * Setter.
     * To set the age of the fruit. For keeping track of the rotting and stuff.
     *
     * @param age a value for the age of the fruit
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * For fruits to experience the passage of time.
     * Increases the age a fruit by 1 at every turn.
     *
     * @param location the location of the fruit
     */
    @Override
    public void tick(Location location) {
        age ++;
        if(age>=15){
            location.removeItem(this);
        }
    }
}
