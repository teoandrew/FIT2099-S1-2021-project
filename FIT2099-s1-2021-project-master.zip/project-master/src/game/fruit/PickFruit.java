package game.fruit;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Item;
import game.PlantTypes;

import java.util.ArrayList;
import java.util.Random;

/**
 * Player picks fruit action. For the player to pick fruit.
 */
public class PickFruit extends Action {

    private ArrayList<Item> fruits;

    /**
     * Constructor.
     *
     * @param fruits fruits on a bush or tree
     */
    public PickFruit(ArrayList<Item> fruits) {
        this.fruits = fruits;
    }

    /**
     * Perform the Action.
     * @see edu.monash.fit2099.engine.Action#execute(Actor, GameMap)
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return the description of what happened for the user to see
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        Random random = new Random();
        int randomInt = random.nextInt(5);
        Fruit fruit = new Fruit();

        if(randomInt>=3){
            actor.addItemToInventory(fruit);
            PlantTypes fruits = (PlantTypes) map.locationOf(actor).getGround();
            fruits.removeFruit();
            return ("PICKED");
        }
        else{return "No Fruit Available ";}
    }

    /**
     * Returns a descriptive string.
     *
     * @param actor The actor performing the action.
     * @return a descriptive string
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Harvest Fruit";
    }
}
