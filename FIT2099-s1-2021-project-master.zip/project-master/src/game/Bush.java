package game;

import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.Location;
import game.dinoCapabilities.EdibleForDinosaur;
import game.fruit.Fruit;

import java.util.ArrayList;
import java.util.Random;


import static game.EcoPoints.addEcoPoints;

/**
 * A class that represents a bush on the ground
 */
public class Bush extends Ground implements PlantTypes{
    // added Bush as per requirement
    private ArrayList<Item> fruits = new ArrayList<>();

    /**
     * Constructor.
     * All bushes are represented by a 'm'.
     */
    public Bush() {
        super('m');

        addCapability(EdibleForDinosaur.STEGOSAUR_CAN_EAT);
    }

    /**
     * For each time a fruit is created it is added to fruits
     * The number of fruits in a bush can be calculated by using .size()
     *
     * @param apple a fruit
     */
    private void createFruit(Fruit apple){
        fruits.add(apple);
        addEcoPoints(1);
    }

    /**
     * When a fruit is picked by the player or eaten by a stegosaur,
     * it is removed from fruits.
     */
    @Override
    public void removeFruit(){
        if(fruits.size()>0){
            fruits.remove(0);
        }
    }

    /**
     * This method is to store the bush location on the GameMap.
     * Getter to get fruits ArrayList
     *
     * @return fruit ArrayList
     */
    @Override
    public ArrayList<Item> getFruits() {
        return fruits;
    }


    /**
     * For the bush to experience the passage of time.
     * At every turn, there is a chance for a fruit
     * to be grown.
     *
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location) {
//        super.tick(location);
        Random random = new Random();
        int randomInt = random.nextInt(10);
        if(randomInt == 0 ){
            Fruit fruit = new Fruit();
            createFruit(fruit);
        }
        if(fruits.size()>0){
            addCapability(PlayerInteraction.PICK_UP_FRUIT_BUSH);
        }
    }
}
