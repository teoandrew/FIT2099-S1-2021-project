package game;

import edu.monash.fit2099.engine.Ground;

/**
 * A class that represents the floor inside a building.
 */
public class Floor extends Ground {

	/**
	 * Constructor.
	 * Floors are displayed as '_' in the GameMap.
	 */
	public Floor() {
		super('_');
	}

}
