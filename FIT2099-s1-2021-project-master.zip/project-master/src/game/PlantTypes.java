package game;

import edu.monash.fit2099.engine.Item;

import java.util.ArrayList;

/**
 * Interface for the Player to get Fruit and remove Fruit.
 */
public interface PlantTypes {

    /**
     * For the player to get fruits.
     *
     * @return the ArrayList of fruits
     */
    ArrayList<Item> getFruits();

    /**
     * For the player to remove fruits.
     */
    void removeFruit();
}