package game;

import edu.monash.fit2099.engine.*;
import game.fruit.PickFruit;
import game.lake.Lakes;

import java.util.Random;

/**
 * Class representing the Player.
 */
public class Player extends Actor {

	private Menu menu = new Menu();
	private int rainTurns = 1;

	/**
	 * Constructor.
	 *
	 * @param name        Name to call the player in the UI
	 * @param displayChar Character to represent the player in the UI
	 * @param hitPoints   Player's starting number of hitpoints
	 */
	public Player(String name, char displayChar, int hitPoints) {
		super(name, displayChar, hitPoints);
	}

	/**
	 * Select and return an action to perform on the current turn.
	 *
	 * @param actions    collection of possible Actions for this Actor
	 * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
	 * @param map        the map containing the Actor
	 * @param display    the I/O object to which messages may be written
	 * @return
	 */
	@Override
	public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
		Random random = new Random();
		int randomInt = random.nextInt(10);
		if(map.locationOf(this).getGround().hasCapability(PlayerInteraction.PICK_UP_FRUIT_BUSH)){
			PlantTypes fruit = (PlantTypes) map.locationOf(this).getGround();
			actions.add(new PickFruit(fruit.getFruits()));
		}
		if(map.locationOf(this).getGround().hasCapability(PlayerInteraction.PICK_UP_FRUIT_TREE)){}
		// Handle multi-turn Actions

		if(randomInt<=1 || rainTurns == 10){
			rainTurns =1;
			for(int y=0; y<=24; y++){
				for(int x=0; x<=70; x++){
					if(map.at(x,y).getGround() instanceof Lakes){
						Lakes lake = (Lakes)map.at(x,y).getGround();
						lake.setRainfall(true);

						if(x+1<=70 && y+1<=24) {
							if (!(map.at(x + 1, y + 1).getGround() instanceof Lakes)) {
								map.at(x + 1, y + 1).setGround(new Lakes());
								break;
							}
						break;

						}
						else if(x-1>=0 && y-1>=0) {
							if (!(map.at(x - 1, y - 1).getGround() instanceof Lakes)) {
								map.at(x - 1, y - 1).setGround(new Lakes());
								break;
							}

						}
					break;
					}


				}
			}
		System.out.println("HEAVY RAIN");
		}
		else{
			for(int y=0; y<=24; y++){
				for(int x=0; x<=79; x++){
					if(map.at(x,y).getGround() instanceof Lakes){
						Lakes lake = (Lakes)map.at(x,y).getGround();
						lake.setRainfall(false);

					}
				}
			}
		}

		if (lastAction.getNextAction() != null)
			return lastAction.getNextAction();
		return menu.showMenu(this, actions, display);
	}
}
