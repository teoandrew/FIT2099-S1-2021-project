package game.dinoCapabilities;

/**
 * An enum class to give a dinosaur egg different species capabilities.
 */
public enum DinosaurSpecies {
    STEGOSAUR, BRACHIOSAUR, ALLOSAUR, PTERODACTYL
}
