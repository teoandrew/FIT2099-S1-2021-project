package game.dinoCapabilities;

/**
 * A enum class to provide flying capabilities.
 */
public enum Fly {
    FLYING
}
