package game.dinoCapabilities;

/**
 * An enum class to give a dinosaur thirsty capabilities.
 */
public enum DinosaurThirstStatus {
    THIRSTY
}
