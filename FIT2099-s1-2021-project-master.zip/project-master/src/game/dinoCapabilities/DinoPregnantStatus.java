package game.dinoCapabilities;

/**
 * An enum class to give a dinosaur pregnant capabilities.
 */
public enum DinoPregnantStatus {
    PREGNANT
}
