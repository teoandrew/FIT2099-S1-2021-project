package game.dinoCapabilities;

/**
 * An enum class to give a dinosaur conscious capabilities.
 */
public enum DinosaurConciousStatus {
    UNCONCSCIOUS, DEAD
}
