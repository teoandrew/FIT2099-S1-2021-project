package game.dinoCapabilities;

/**
 * An enum class to give a dinosaur hunger capabilities.
 */
public enum DinosaurHungerStatus {
    NOT_HUNGRY, HUNGRY
}
