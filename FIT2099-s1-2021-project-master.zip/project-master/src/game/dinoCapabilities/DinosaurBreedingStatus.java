package game.dinoCapabilities;

/**
 * An enum class to give a dinosaur breeding capabilities.
 */
public enum DinosaurBreedingStatus {
    READY_TO_BREED
}
