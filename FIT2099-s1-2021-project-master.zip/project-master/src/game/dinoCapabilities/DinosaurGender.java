package game.dinoCapabilities;

/**
 * An enum class to give a dinosaur gender capabilities.
 */
public enum DinosaurGender {
    MALE, FEMALE
}
