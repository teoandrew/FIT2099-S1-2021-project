package game.dinoCapabilities;

/**
 * An enum class to give a certain food source specific capibilities
 * to which dinosaur can eat them.
 */
public enum EdibleForDinosaur {
    STEGOSAUR_CAN_EAT, BRACHIOSAUR_CAN_EAT, ALLOSAUR_CAN_EAT, PTERODACTYL_CAN_EAT
}
