package game.dinoCapabilities;

/**
 * An enum class to give a dinosaur diet capabilities.
 */
public enum DinosaurDiet {
    HERBIVORE, CARNIVORE
}
