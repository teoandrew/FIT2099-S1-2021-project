package game;

import java.util.Arrays;
import java.util.List;
import edu.monash.fit2099.engine.*;
import game.dinoCapabilities.DinosaurGender;
import game.dinosaurs.Brachiosaur;
import game.dinosaurs.Pterodactyl;
import game.dinosaurs.Stegosaur;
import game.lake.Lakes;
import game.vendingMachine.VendingMachine;

/**
 * The main class for the Jurassic World game.
 *
 */
public class Application {

	public static void main(String[] args) {
		World world = new World(new Display());

		FancyGroundFactory groundFactory = new FancyGroundFactory(new Dirt(), new Wall(), new Floor(), new Tree());

		List<String> map = Arrays.asList(
		"................................................................................",
		"................................................................................",
		".....#######....................................................................",
		".....#_____#....................................................................",
		".....#_____#....................................................................",
		".....###.###....................................................................",
		"................................................................................",
		"......................................+++.......................................",
		".......................................++++.....................................",
		"...................................+++++........................................",
		".....................................++++++.....................................",
		"......................................+++.......................................",
		".....................................+++........................................",
		"................................................................................",
		"............+++.................................................................",
		".............+++++..............................................................",
		"...............++........................................+++++..................",
		".............+++....................................++++++++....................",
		"............+++.......................................+++.......................",
		"................................................................................",
		".........................................................................++.....",
		"........................................................................++.++...",
		".........................................................................++++...",
		"..........................................................................++....",
		"................................................................................");
		GameMap gameMap = new GameMap(groundFactory, map );
		world.addGameMap(gameMap);
		
		Actor player = new Player("Player", '@', 100);
		world.addPlayer(player, gameMap.at(9, 4));


		List<String> gateway = Arrays.asList(
				"................................................................................",
				"................................................................................",
				".....#######....................................................................",
				".....#_____#....................................................................",
				".....#_____#....................................................................",
				".....###.###....................................................................",
				"................................................................................",
				"......................................+++.......................................",
				".......................................++++.....................................",
				"...................................+++++........................................",
				".....................................++++++.....................................",
				"......................................+++.......................................",
				".....................................+++........................................",
				"................................................................................",
				"............+++.................................................................",
				".............+++++..............................................................",
				"...............++........................................+++++..................",
				".............+++....................................++++++++....................",
				"............+++.......................................+++.......................",
				"................................................................................",
				".........................................................................++.....",
				"........................................................................++.++...",
				".........................................................................++++...",
				"..........................................................................++....",
				"................................................................................");

		GameMap gameMap2 = new GameMap(groundFactory,gateway);
		world.addGameMap(gameMap2);
		Entrance entrance =  new Entrance();
		entrance.addAction(new MoveActorAction(gameMap2.at(gameMap.getXRange().max(),gameMap.getYRange().max()),", DO YOU DARE ENTER PARADISE???"));
		gameMap.at(13,0).addItem(entrance);


		Entrance entrance1 = new Entrance();
		entrance1.addAction(new MoveActorAction(gameMap.at(gameMap.getXRange().min(),gameMap.getYRange().min()),"Welcome back to the real world"));
		gameMap2.at(gameMap.getXRange().max(),gameMap.getYRange().max()).addItem(entrance1);




		
		// Place a pair of stegosaurus in the middle of the map
		Stegosaur stegosaur1 = new Stegosaur("Stegosaur 1");
		Stegosaur stegosaur2 = new Stegosaur("Stegosaur 2");
		gameMap.at(30, 12).addActor(stegosaur1);
		gameMap.at(32, 12).addActor(stegosaur2);

		stegosaur1.addCapability(DinosaurGender.MALE);
		stegosaur2.addCapability(DinosaurGender.FEMALE);

		// Place a pair of brachiosaurs on the top right of the map
		Brachiosaur brachiosaur1 = new Brachiosaur("Brachiosaur 1");
		Brachiosaur brachiosaur2 = new Brachiosaur("Brachiosaur 2");
		gameMap.at(64, 3).addActor(brachiosaur1);
		gameMap.at(66, 3).addActor(brachiosaur2);

		brachiosaur1.addCapability(DinosaurGender.MALE);
		brachiosaur2.addCapability(DinosaurGender.FEMALE);

		// Place a pair of pterodactyls on the map
		Pterodactyl pterodactyl1 = new Pterodactyl("Pterodactyl 1");
		Pterodactyl pterodactyl2 = new Pterodactyl("Pterodactyl 2");
		gameMap.at(3, 20).addActor(pterodactyl1);
		gameMap.at(3, 22).addActor(pterodactyl2);

		pterodactyl1.addCapability(DinosaurGender.MALE);
		pterodactyl1.addCapability(DinosaurGender.FEMALE);

		// TEMPORARY CODE TO INITIALISE SOME LAKES SINCE THERE'S NO LAKES CURRENTLY (FOR TESTING)
//		gameMap.at(4, 20).setGround(new Lakes());
//		gameMap.at(4, 22).setGround(new Lakes());
//		gameMap.at(2, 20).setGround(new Lakes());
//		gameMap.at(2, 22).setGround(new Lakes());
//		gameMap.at(3, 21).setGround(new Lakes());
//		gameMap.at(3, 19).setGround(new Lakes());
//		gameMap.at(3, 23).setGround(new Lakes());

		//added vendingMachine
		gameMap.at(0,0).setGround(new VendingMachine());

		gameMap.at(12,11).setGround(new Lakes());

		// TEMPORARY CODE TO INITIALISE SOME BUSHES SINCE I REMOVED ALL BUSHES FOR TESTING PURPOSES
		gameMap.at(54, 5).setGround(new Bush());
		gameMap.at(55, 5).setGround(new Bush());
		gameMap.at(54, 6).setGround(new Bush());
		gameMap.at(55, 6).setGround(new Bush());

		world.run();
	}
}
